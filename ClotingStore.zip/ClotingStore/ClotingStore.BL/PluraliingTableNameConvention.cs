﻿namespace ClotingStore.BL
{
    internal class PluraliingTableNameConvention
    {
    }
}